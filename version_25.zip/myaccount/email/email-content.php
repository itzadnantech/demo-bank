<table class="es-content" cellspacing="0" cellpadding="0" align="center" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                            <tbody bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                    <td class="esd-stripe" esd-custom-block-id="6023" align="center" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                        <table class="es-content-body" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                            <tbody bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                    <td class="esd-structure es-p40t es-p40b es-p30r es-p30l" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                        <table width="100%" cellspacing="0" cellpadding="0" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                            <tbody bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                    <td class="esd-container-frame" esd-custom-block-id="11296" width="540" valign="top" align="center" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                        <table width="100%" cellspacing="0" cellpadding="0" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                            <tbody bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <h3 style="color: #666666;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">Dear, <?php echo"$firstname $middlename $lastname"; ?><br bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}"></h3>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text es-p15t" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}"><?php echo "$message" ?></p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text es-p15t" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">I am an account executive at Financial company. We provide extensive assistance with any audit issues to modern businesses. You had partnered with some our clients like CustomerName1 and CustomerName2. I believe I could be of great value for your business and would love to work with you.<br bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}"></p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text es-p15t" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">Are you available for a 15 minute-meeting on Monday (June 18th) at 9:00 am. Let me know if it sounds good for you.</p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text es-p25t" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">Thanks for your time! I am sincerely grateful!<br bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}"></p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                    <td class="esd-block-text es-p15t" align="left" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">Best regards,</p>
                                                                                        <p style="color: #999999;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:315,&quot;abs_y&quot;:65}">Adam Kendal</p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>