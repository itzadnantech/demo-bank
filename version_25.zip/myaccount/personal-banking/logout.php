<?php
include("../scripts/functions.php");
session_destroy();
header("location:/");

?>